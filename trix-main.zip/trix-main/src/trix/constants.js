export const ZERO_WIDTH_SPACE = "\uFEFF"
export const NON_BREAKING_SPACE = "\u00A0"
export const OBJECT_REPLACEMENT_CHARACTER = "\uFFFC"
