export default () =>
  `<table>
    <tr>
      <td>
        <trix-editor></trix-editor>
      </td>
    </tr>
  </table>`
