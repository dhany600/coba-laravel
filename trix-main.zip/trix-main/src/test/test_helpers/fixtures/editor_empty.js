export default () => "<trix-editor autofocus placeholder=\"Say hello...\"></trix-editor>"
